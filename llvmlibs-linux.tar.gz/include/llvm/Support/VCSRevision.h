#define LLVM_REVISION "bb9faf3c8b4e0de05d07cbe623a1bf45874b5174"
#define LLVM_REPOSITORY "https://github.com/RPCS3/llvm-mirror"
